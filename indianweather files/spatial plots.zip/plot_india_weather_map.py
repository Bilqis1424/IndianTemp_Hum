"""
Interactive India weather map — raw vs. predicted temperature & humidity.
================================================================================
Uses geopandas to load and simplify an India state-boundary basemap, and
folium to render an interactive HTML map. Every one of the 543 locations in
the dataset gets a clickable marker; clicking (or hovering) shows a popup
with:
  - The most recent RAW (observed) temperature/humidity reading
  - The stacked ensemble's PREDICTED temperature/humidity for that same
    timestamp (out-of-sample — these are test-set predictions, not
    in-sample fitted values)
  - That city's test-period MAE for both variables, so the popup also
    conveys how reliable the prediction typically is at that location
The 8 study cities (Delhi, Mumbai, Chennai, Kolkata, Bengaluru, Pune,
Jaipur, Lucknow) are rendered as larger, distinctly colored star markers so
they stand out from the other 535 locations.

TWO WAYS TO RUN THIS
------------------------
1. FAST PATH (default): loads a precomputed summary CSV
   (`checkpoints/city_map_summary.csv`) if present — this is instant since
   no model/data reloading is needed.
2. REGENERATION PATH: if that CSV isn't found, this script rebuilds it from
   scratch — loads the raw Excel file, the saved stacked model
   (`checkpoints/stacked_model_final.pkl`), reconstructs features, and
   re-derives test-set predictions per city. This requires
   indian_weather_pipeline_v3_final.py to be in the same directory (it
   supplies feature engineering + the TimeSeriesStackingRegressor class
   needed to unpickle the saved model) and is slower (a few minutes) but
   makes this script fully self-contained/reproducible on a fresh machine.
================================================================================
"""

import os
import sys
import json

import numpy as np
import pandas as pd
import geopandas as gpd
import folium
from folium import Popup

# ============================================================================
# CONFIG
# ============================================================================

CHECKPOINT_DIR = "checkpoints"
SUMMARY_CSV = os.path.join(CHECKPOINT_DIR, "city_map_summary.csv")
OUTPUT_HTML = "india_weather_map.html"

STATE_GEOJSON_URL = "https://raw.githubusercontent.com/geohacker/india/master/state/india_state.geojson"
STATE_GEOJSON_CACHE = "india_states_simplified.geojson"
SIMPLIFY_TOLERANCE = 0.02  # degrees — trades boundary detail for a much smaller/faster map

STUDY_CITIES = {
    "New Delhi": "Delhi", "Mumbai": "Mumbai", "Chennai": "Chennai", "Kolkata": "Kolkata",
    "Bangalore": "Bengaluru", "Pune": "Pune", "Jaipur": "Jaipur", "Lucknow": "Lucknow",
}

INDIA_CENTER = [22.5, 79.0]


# ============================================================================
# STEP 1: PER-CITY SUMMARY (raw vs predicted) — fast path or regenerate
# ============================================================================

def regenerate_summary():
    """
    [REGENERATION PATH] Rebuilds the per-city raw-vs-predicted summary from
    scratch. Only runs if the cached CSV isn't found. Requires
    indian_weather_pipeline_v3_final.py alongside this script and the raw
    data file / saved model to be reachable at the paths configured there.
    """
    print("No cached summary found — regenerating from raw data + saved model "
          "(this will take a few minutes: reloads XGBoost/LightGBM/CatBoost model).")
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import indian_weather_pipeline_v3_final as p
    import joblib

    df_raw = p.load_and_validate(p.FILEPATH)
    df_full, X_train, X_test, y_train, y_test, le_region, le_cond, le_city, feature_names = p.prepare_data(df_raw)
    model = joblib.load(os.path.join(CHECKPOINT_DIR, "stacked_model_final.pkl"))
    y_pred = model.predict(X_test)

    test_info = df_full.loc[X_test.index, ["city", "region", "latitude", "longitude", "datetime", "temp", "hum"]].copy()
    test_info["pred_temp"] = y_pred[:, 0]
    test_info["pred_hum"] = y_pred[:, 1]
    test_info = test_info.sort_values("datetime")

    latest = test_info.groupby("city", as_index=False).tail(1).reset_index(drop=True)
    city_mae = test_info.groupby("city").apply(
        lambda g: pd.Series({
            "test_temp_mae": (g["temp"] - g["pred_temp"]).abs().mean(),
            "test_hum_mae": (g["hum"] - g["pred_hum"]).abs().mean(),
            "n_test_rows": len(g),
        }), include_groups=False
    ).reset_index()

    summary = latest.merge(city_mae, on="city")
    summary["is_study_city"] = summary["city"].isin(STUDY_CITIES)
    summary["display_name"] = summary["city"].map(lambda c: STUDY_CITIES.get(c, c))
    summary["temp_error"] = summary["pred_temp"] - summary["temp"]
    summary["hum_error"] = summary["pred_hum"] - summary["hum"]

    os.makedirs(CHECKPOINT_DIR, exist_ok=True)
    summary.to_csv(SUMMARY_CSV, index=False)
    print(f"Regenerated and cached: {SUMMARY_CSV}")
    return summary


def load_summary():
    if os.path.exists(SUMMARY_CSV):
        print(f"Loading cached summary: {SUMMARY_CSV}")
        df = pd.read_csv(SUMMARY_CSV, parse_dates=["datetime"])
    else:
        df = regenerate_summary()

    # [DATA INTEGRITY GUARD] Same sanity check used throughout this project —
    # refuse to plot a city whose raw or predicted values are physically
    # impossible rather than silently rendering a corrupted marker.
    bad = df[(df["hum"] < 0) | (df["hum"] > 100) | (df["pred_hum"] < 0) | (df["pred_hum"] > 100) |
             (df["temp"] < -20) | (df["temp"] > 55) | (df["pred_temp"] < -20) | (df["pred_temp"] > 55)]
    if len(bad):
        print(f"!! WARNING: dropping {len(bad)} cities with out-of-range raw/predicted values "
              f"before plotting: {bad['city'].tolist()}")
        df = df[~df.index.isin(bad.index)]
    return df


# ============================================================================
# STEP 2: BASEMAP — India state boundaries via geopandas
# ============================================================================

def load_state_boundaries():
    if os.path.exists(STATE_GEOJSON_CACHE):
        print(f"Loading cached simplified boundaries: {STATE_GEOJSON_CACHE}")
        return gpd.read_file(STATE_GEOJSON_CACHE)

    print(f"Downloading India state boundaries from {STATE_GEOJSON_URL} ...")
    gdf = gpd.read_file(STATE_GEOJSON_URL)
    # Simplify geometry — the source file is ~22MB of high-resolution polygons;
    # a weather-city map needs state OUTLINES, not survey-grade boundary
    # detail, and the full-resolution version would make the resulting HTML
    # file large and slow to pan/zoom in a browser.
    gdf["geometry"] = gdf["geometry"].simplify(SIMPLIFY_TOLERANCE, preserve_topology=True)
    gdf = gdf[["NAME_1", "geometry"]]
    gdf.to_file(STATE_GEOJSON_CACHE, driver="GeoJSON")
    print(f"Cached simplified boundaries to {STATE_GEOJSON_CACHE}")
    return gdf


# ============================================================================
# STEP 3: BUILD THE INTERACTIVE MAP
# ============================================================================

def error_to_color(abs_error, low=0.5, high=3.0):
    """Green (accurate) -> yellow -> red (large error), for the small city markers."""
    if pd.isna(abs_error):
        return "#808080"
    t = np.clip((abs_error - low) / (high - low), 0, 1)
    r = int(255 * t)
    g = int(255 * (1 - t))
    return f"#{r:02x}{g:02x}00"


def build_popup_html(row):
    date_str = pd.Timestamp(row["datetime"]).strftime("%Y-%m-%d %H:%M")
    return f"""
    <div style="font-family: Arial, sans-serif; font-size: 13px; min-width: 220px;">
      <b style="font-size:15px;">{row['display_name']}</b>
      <span style="color:#666;">({row['region']})</span><br>
      <span style="color:#999; font-size:11px;">Reading: {date_str}</span>
      <table style="margin-top:6px; border-collapse: collapse; width: 100%;">
        <tr style="border-bottom:1px solid #ddd;">
          <td></td><td><b>Raw</b></td><td><b>Predicted</b></td>
        </tr>
        <tr>
          <td>Temperature</td>
          <td>{row['temp']:.1f} &deg;C</td>
          <td>{row['pred_temp']:.1f} &deg;C</td>
        </tr>
        <tr>
          <td>Humidity</td>
          <td>{row['hum']:.0f}%</td>
          <td>{row['pred_hum']:.0f}%</td>
        </tr>
      </table>
      <div style="margin-top:6px; font-size:11px; color:#666;">
        Test-period MAE at this location: {row['test_temp_mae']:.2f}&deg;C temp,
        {row['test_hum_mae']:.2f}% humidity ({int(row['n_test_rows'])} test readings)
      </div>
    </div>
    """


def build_map(summary_df, states_gdf):
    m = folium.Map(location=INDIA_CENTER, zoom_start=5, tiles="CartoDB positron")

    folium.GeoJson(
        states_gdf,
        name="State boundaries",
        style_function=lambda f: {"fillColor": "#00000000", "color": "#888888", "weight": 1},
        tooltip=folium.GeoJsonTooltip(fields=["NAME_1"], aliases=["State:"]),
    ).add_to(m)

    other_layer = folium.FeatureGroup(name="Other locations (535)")
    study_layer = folium.FeatureGroup(name="Study cities (8)")

    for _, row in summary_df.iterrows():
        popup = Popup(build_popup_html(row), max_width=280)
        if row["is_study_city"]:
            folium.Marker(
                location=[row["latitude"], row["longitude"]],
                popup=popup,
                tooltip=row["display_name"],
                icon=folium.Icon(color="blue", icon="star", prefix="fa"),
            ).add_to(study_layer)
        else:
            color = error_to_color(abs(row["temp_error"]))
            folium.CircleMarker(
                location=[row["latitude"], row["longitude"]],
                radius=4,
                popup=popup,
                tooltip=row["display_name"],
                color=color, fill=True, fill_color=color, fill_opacity=0.8, weight=1,
            ).add_to(other_layer)

    other_layer.add_to(m)
    study_layer.add_to(m)
    folium.LayerControl(collapsed=False).add_to(m)

    legend_html = """
    <div style="position: fixed; bottom: 30px; left: 30px; z-index: 9999;
                background: white; padding: 10px 14px; border: 1px solid #999;
                border-radius: 6px; font-family: Arial, sans-serif; font-size: 12px;">
      <b>India Weather: Raw vs. Predicted</b><br>
      <span style="color:#0074D9;">&#9733;</span> Study city (8)<br>
      <span style="color:#2ecc40;">&#9679;</span> Other location — low temp error<br>
      <span style="color:#ff851b;">&#9679;</span> Other location — moderate error<br>
      <span style="color:#ff4136;">&#9679;</span> Other location — high error<br>
      <span style="font-size:10px; color:#666;">Click any marker for raw/predicted values</span>
    </div>
    """
    m.get_root().html.add_child(folium.Element(legend_html))
    return m


# ============================================================================
# MAIN
# ============================================================================

def main():
    summary_df = load_summary()
    print(f"Plotting {len(summary_df)} locations "
          f"({summary_df['is_study_city'].sum()} study cities).")

    states_gdf = load_state_boundaries()

    m = build_map(summary_df, states_gdf)
    m.save(OUTPUT_HTML)
    print(f"Saved interactive map to {OUTPUT_HTML}")


if __name__ == "__main__":
    main()
